# API名稱與目錄對照
|目錄                   |API名稱|                                             
|:--                    |:--|
|/barcode               |條碼繳費-幕後取號串接|
|/creditcard            |信用卡幕後授權|
|/creditcard_agreement  |約定信用卡付款授權|
|/creditcard_batch      |批次約定信用卡付款授權|
|/creditcard_cancel     |信用卡-取消授權|
|/creditcard_close      |信用卡-請退款|
|/creditcard_pay_page   |嵌入式支付頁|
|/cvs                   |超商代碼繳費-幕後取號串接|
|/ewallet_refund        |電子錢包退款|
|/get_transaction_info  |單日交易查詢|
|/MPG                   |多功能收款 MPG|
|/period                |信用卡-定期定額|
|/query_trade_info      |單筆交易狀態查詢|
|/refund                |非信用卡支付商店訂單退款|
|/report_refund         |單日撥款提領明細查詢|
|/web_atm               |WebATM 串接|
